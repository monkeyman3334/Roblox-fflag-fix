﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Runtime.InteropServices;
using Newtonsoft.Json; // <-- ADDED THIS LINE
using Newtonsoft.Json.Linq;
using Microsoft.Win32;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace RobloxFFlagEditor_1k
{
    // Implementation of INotifyPropertyChanged is REQUIRED for WPF data binding to update the UI
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private string _settingsFilePath = string.Empty;
        private string _fileContent = string.Empty;
        private string _statusMessage = "Status: Ready. Select a file to begin.";
        private Brush _statusColor = Brushes.LightGray;
        private bool _isFileReadOnly = false;

        // --- Data Binding Properties (The View/UI reads these) ---

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public string FilePathDisplay => _settingsFilePath.Length > 0
            ? $"FILE: {Path.GetFileName(_settingsFilePath)} | PATH: {Path.GetDirectoryName(_settingsFilePath)}"
            : "CURRENT FILE: Not Selected";

        public bool IsFileSelected => !string.IsNullOrEmpty(_settingsFilePath);

        public bool IsFileReadOnly
        {
            get => _isFileReadOnly;
            set
            {
                if (_isFileReadOnly != value)
                {
                    _isFileReadOnly = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(ReadOnlyButtonText));
                    OnPropertyChanged(nameof(ReadOnlyButtonColor));
                }
            }
        }

        public string ReadOnlyButtonText => IsFileReadOnly ? "🔒 Toggle Read-Only (LOCKED)" : "🔓 Toggle Read-Only (UNLOCKED)";
        public Brush ReadOnlyButtonColor => IsFileReadOnly ? new SolidColorBrush(Color.FromArgb(0xFF, 0xCC, 0x55, 0x55)) : new SolidColorBrush(Color.FromArgb(0xFF, 0x00, 0x7A, 0xCC));

        public string FileContent
        {
            get => _fileContent;
            set
            {
                if (_fileContent != value)
                {
                    _fileContent = value;
                    OnPropertyChanged();
                }
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                if (_statusMessage != value)
                {
                    _statusMessage = value;
                    OnPropertyChanged();
                }
            }
        }

        public Brush StatusColor
        {
            get => _statusColor;
            set
            {
                if (_statusColor != value)
                {
                    _statusColor = value;
                    OnPropertyChanged();
                }
            }
        }

        // Standard template for a fresh ClientAppSettings.json file
        private const string DEFAULT_JSON_TEMPLATE =
@"{
    ""FFlagTestFlag"": false,
    ""FIntTestFlag"": 0,
    ""DFFlagTestFlag"": false
}";


        // --- Constructor and Initialization ---

        public MainWindow()
        {
            InitializeComponent();
            // This sets the DataContext so the XAML bindings work
            this.DataContext = this;
        }

        // --- Windows API for File Attributes ---

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern uint GetFileAttributes(string lpFileName);

        private const uint FILE_ATTRIBUTE_READONLY = 0x00000001;
        private const uint INVALID_FILE_ATTRIBUTES = 0xFFFFFFFF;


        // --- Core File Utility Methods ---

        private string GetRobloxVersionsPath()
        {
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            return Path.Combine(localAppData, "Roblox", "Versions");
        }

        private bool IsFileReadOnlyAttributeSet(string path)
        {
            if (string.IsNullOrEmpty(path) || !File.Exists(path)) return false;
            uint attributes = GetFileAttributes(path);
            return (attributes != INVALID_FILE_ATTRIBUTES) && ((attributes & FILE_ATTRIBUTE_READONLY) != 0);
        }

        /// <summary>
        /// Updates the status bar text and color.
        /// </summary>
        private void UpdateStatus(string message, StatusType type)
        {
            StatusMessage = message;

            switch (type)
            {
                case StatusType.Success:
                    // Soft Green for success/ready
                    StatusColor = new SolidColorBrush(Color.FromArgb(0xFF, 0x98, 0xC3, 0x79));
                    break;
                case StatusType.Error:
                    // Red for errors
                    StatusColor = new SolidColorBrush(Color.FromArgb(0xFF, 0xF4, 0x66, 0x66));
                    break;
                case StatusType.Warning:
                    // Yellow/Orange for warnings
                    StatusColor = new SolidColorBrush(Color.FromArgb(0xFF, 0xE5, 0xC0, 0x7B));
                    break;
                case StatusType.Info:
                    // Blue for general info/actions
                    StatusColor = new SolidColorBrush(Color.FromArgb(0xFF, 0x61, 0xAF, 0xEF));
                    break;
            }
        }

        private enum StatusType { Success, Error, Warning, Info }


        // --- JSON and Formatting Methods ---

        /// <summary>
        /// Checks if the content is valid JSON using Newtonsoft.Json.
        /// </summary>
        private bool IsContentValidJson()
        {
            string content = FileContent.Trim();
            if (string.IsNullOrEmpty(content)) return true;

            try
            {
                JToken.Parse(content);
                return true;
            }
            catch (JsonReaderException ex)
            {
                UpdateStatus($"JSON VALIDATION ERROR: Line {ex.LineNumber}, Position {ex.LinePosition}. Message: {ex.Message}", StatusType.Error);
                return false;
            }
        }

        /// <summary>
        /// Attempts to format and indent the JSON content.
        /// </summary>
        private void FormatJson_Click(object sender, RoutedEventArgs e)
        {
            string content = FileContent.Trim();
            if (string.IsNullOrEmpty(content))
            {
                UpdateStatus("Editor is empty.", StatusType.Info);
                return;
            }

            try
            {
                JToken parsedJson = JToken.Parse(content);
                FileContent = parsedJson.ToString(Formatting.Indented);
                UpdateStatus("JSON content formatted successfully.", StatusType.Info);
            }
            catch (JsonReaderException ex)
            {
                UpdateStatus($"FORMAT ERROR: Cannot format, invalid JSON structure: {ex.Message}", StatusType.Error);
            }
            catch (Exception ex)
            {
                UpdateStatus($"An unexpected error occurred during formatting: {ex.Message}", StatusType.Error);
            }
        }


        // --- Event Handlers (Click methods) ---

        private void SelectFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Roblox Settings Files|IxpSettings.json;ClientAppSettings.json|All Files (*.*)|*.*";
            ofd.InitialDirectory = GetRobloxVersionsPath();

            if (ofd.ShowDialog() == true)
            {
                LoadFileContent(ofd.FileName);
            }
        }

        private void NewFile_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "Do you want to start a new ClientAppSettings.json file using a default template?\n\nWARNING: Any unsaved changes will be lost.",
                "Create New Settings File",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                FileContent = DEFAULT_JSON_TEMPLATE;
                _settingsFilePath = string.Empty;
                OnPropertyChanged(nameof(FilePathDisplay));
                OnPropertyChanged(nameof(IsFileSelected));
                IsFileReadOnly = false;
                UpdateStatus("New file template loaded. Use 'Save Changes' to save it to disk.", StatusType.Info);
            }
        }

        private void LoadFileContent(string path)
        {
            if (!File.Exists(path))
            {
                UpdateStatus("ERROR: File not found.", StatusType.Error);
                return;
            }

            try
            {
                FileContent = File.ReadAllText(path);
                _settingsFilePath = path;
                OnPropertyChanged(nameof(FilePathDisplay));
                OnPropertyChanged(nameof(IsFileSelected));

                IsFileReadOnly = IsFileReadOnlyAttributeSet(path);

                if (IsFileReadOnly)
                {
                    UpdateStatus("File loaded. WARNING: Read-Only flag is currently set.", StatusType.Warning);
                }
                else
                {
                    UpdateStatus("File loaded successfully and is currently writable.", StatusType.Success);
                }
            }
            catch (Exception ex)
            {
                UpdateStatus($"ERROR loading file: {ex.Message}", StatusType.Error);
            }
        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            // 1. Validate JSON first
            if (!IsContentValidJson())
            {
                // IsContentValidJson already updates the error status
                return;
            }

            // 2. Handle "Save As" if no path is set
            if (string.IsNullOrEmpty(_settingsFilePath))
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "JSON Files|*.json";
                sfd.InitialDirectory = GetRobloxVersionsPath();
                sfd.FileName = "ClientAppSettings.json";

                if (sfd.ShowDialog() == true)
                {
                    _settingsFilePath = sfd.FileName;
                    OnPropertyChanged(nameof(FilePathDisplay));
                }
                else
                {
                    UpdateStatus("Save As cancelled.", StatusType.Info);
                    return;
                }
            }

            // 3. Attempt to save the content
            try
            {
                File.WriteAllText(_settingsFilePath, FileContent);
                UpdateStatus("SUCCESS: Changes saved to file.", StatusType.Success);
            }
            catch (UnauthorizedAccessException)
            {
                UpdateStatus("ERROR: Cannot save. File is Read-Only or permission denied. Unlock the file first.", StatusType.Error);
            }
            catch (Exception ex)
            {
                UpdateStatus($"ERROR saving file: {ex.Message}", StatusType.Error);
            }
        }

        private void ToggleReadOnly_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(_settingsFilePath) || !File.Exists(_settingsFilePath))
            {
                UpdateStatus("ERROR: No file is selected or found.", StatusType.Error);
                return;
            }

            try
            {
                // This WPF method is more reliable for checking/setting attributes
                FileAttributes attributes = File.GetAttributes(_settingsFilePath);

                if (IsFileReadOnly)
                {
                    // If it's ReadOnly, turn it off (make it writable)
                    attributes &= ~FileAttributes.ReadOnly;
                    File.SetAttributes(_settingsFilePath, attributes);
                    IsFileReadOnly = false;
                    UpdateStatus("File is now Writable (UNLOCKED).", StatusType.Info);
                }
                else
                {
                    // If it's writable, turn it on (make it ReadOnly)
                    attributes |= FileAttributes.ReadOnly;
                    File.SetAttributes(_settingsFilePath, attributes);
                    IsFileReadOnly = true;
                    UpdateStatus("File is now Read-Only (LOCKED).", StatusType.Info);
                }
            }
            catch (Exception ex)
            {
                UpdateStatus($"ERROR toggling read-only attribute: {ex.Message}", StatusType.Error);
            }
        }
    }
}
